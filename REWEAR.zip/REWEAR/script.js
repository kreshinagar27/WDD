const defaultProducts = [
  { id: 1, name: "Vintage Denim Jacket", category: "Jackets", price: 1299, condition: "Like New", image: "images/jacket.jpg" },
  { id: 2, name: "Cozy Knit Wool Sweater", category: "Tops", price: 899, condition: "Gently Used", image: "images/sweater.jpg" },
  { id: 3, name: "High-Waist Mom Jeans", category: "Denim", price: 999, condition: "Like New", image: "images/jeans.jpg" },
  { id: 4, name: "Retro Canvas Sneakers", category: "Shoes", price: 749, condition: "Gently Used", image: "images/shoes.jpg" }
];
function load(key, fallback) {
  const saved = localStorage.getItem(key);
  if (saved) return JSON.parse(saved);
  return fallback;
}
function saveCart(cart) {
  localStorage.setItem("rewear_cart", JSON.stringify(cart));
  let count = 0;
  for (let i = 0; i < cart.length; i++) count += cart[i].quantity;
  set("cart-count", count);
}
function val(id) {
  const el = document.getElementById(id);
  if (el) return el.value.trim();
  return "";
}
function set(id, html, display) {
  const el = document.getElementById(id);
  if (!el) return;
  if (html !== null) el.innerHTML = html;
  if (display) el.style.display = display;
}
function renderCard(p) {
  return '<div class="product-card"><div class="product-image-container"><img src="' + p.image + '" alt="' + p.name + '" class="product-image"></div><div class="product-details"><span class="product-category">' + p.category + '</span><h3 class="product-name">' + p.name + '</h3><span class="product-condition">' + p.condition + '</span><div class="product-price">₹' + p.price + '</div><button type="button" class="btn" onclick="addToCart(' + p.id + ')">Add to Cart</button></div></div>';
}

function changeQuantity(id, delta) {
  const cart = load("rewear_cart", []);
  const updated = [];
  let found = false;
  for (let i = 0; i < cart.length; i++) {
    if (cart[i].id === id) {
      cart[i].quantity += delta;
      found = true;
    }
    if (cart[i].quantity > 0) updated.push(cart[i]);
  }
  if (!found && delta > 0) {
    const list = load("rewear_products", defaultProducts);
    for (let i = 0; i < list.length; i++) {
      const p = list[i];
      if (p.id === id) updated.push({ id: p.id, name: p.name, price: p.price, category: p.category, image: p.image, quantity: 1 });
    }
  }
  saveCart(updated);
  renderCart();
}
function addToCart(id) {
  changeQuantity(id, 1);
  alert("Item added to cart!");
}
function removeFromCart(id) {
  changeQuantity(id, -999);
}

function renderProducts() {
  const list = load("rewear_products", defaultProducts);
  const box = document.getElementById("featured-container") || document.getElementById("products-container");
  if (!box) return;
  const isHome = (box.id === "featured-container");
  const q = val("search-input").toLowerCase();
  const c = val("category-filter").toLowerCase();
  let cards = "";
  for (let i = 0; i < list.length; i++) {
    const p = list[i];
    const matchName = p.name.toLowerCase().indexOf(q) !== -1;
    const matchCat = (c === "" || c === "all" || p.category.toLowerCase() === c);
    if (isHome && i < 4) cards += renderCard(p);
    if (!isHome && matchName && matchCat) cards += renderCard(p);
  }
  if (cards === "") cards = '<div class="empty-view" style="grid-column:1/-1;"><h3>No products found</h3></div>';
  box.innerHTML = cards;
}

function renderCart() {
  const cart = load("rewear_cart", []);
  const table = document.getElementById("cart-items");
  const summaryBox = document.getElementById("checkout-items");
  let lay = "flex";
  let emp = "none";
  if (cart.length === 0) {
    lay = "none";
    emp = "block";
  }
  let subtotal = 0;
  let rows = "";
  let summary = "";
  for (let i = 0; i < cart.length; i++) {
    const item = cart[i];
    const total = item.price * item.quantity;
    subtotal += total;
    if (table) rows += '<tr><td><div class="cart-item-row"><img src="' + item.image + '" alt="' + item.name + '" class="cart-thumb"><div><strong>' + item.name + '</strong><div style="font-size:12px;color:#777;">' + item.category + '</div></div></div></td><td>₹' + item.price + '</td><td><div class="qty-box"><button type="button" class="qty-btn" onclick="changeQuantity(' + item.id + ', -1)">−</button><span class="qty-val">' + item.quantity + '</span><button type="button" class="qty-btn" onclick="changeQuantity(' + item.id + ', 1)">+</button></div></td><td>₹' + total + '</td><td><button type="button" class="btn btn-danger btn-sm" onclick="removeFromCart(' + item.id + ')">✕ Remove</button></td></tr>';
    if (summaryBox) summary += '<div class="summary-line"><span>' + item.quantity + '× ' + item.name + '</span><span>₹' + total + '</span></div>';
  }
  if (table) table.innerHTML = rows;
  if (summaryBox) summaryBox.innerHTML = summary;
  let shipping = 79;
  let shipText = "₹79";
  if (subtotal >= 999 || subtotal === 0) {
    shipping = 0;
    shipText = "FREE";
  }
  let p = "cart";
  if (summaryBox) p = "checkout";
  set(p + "-layout", null, lay);
  set(p + "-empty-view", null, emp);
  set(p + "-subtotal", "₹" + subtotal);
  set(p + "-shipping", shipText);
  set(p + "-total", "₹" + (subtotal + shipping));
}

function initCheckout() {
  const form = document.getElementById("checkout-form");
  if (!form) return;
  form.onsubmit = function (event) {
    event.preventDefault();
    set("checkout-error", null, "none");
    const name = val("cust-name");
    if (!name || !val("cust-address") || !val("cust-city") || val("cust-email").indexOf("@") === -1 || val("cust-phone").length !== 10 || val("cust-pin").length !== 6) {
      set("checkout-error", "Please enter valid details in all fields.", "block");
      return;
    }
    set("modal-order-number", "#RW-" + Math.floor(1000 + Math.random() * 9000));
    set("modal-order-name", name);
    const totalEl = document.getElementById("checkout-total");
    if (totalEl) set("modal-order-total", totalEl.innerHTML);
    saveCart([]);
    const modal = document.getElementById("order-modal");
    if (modal) modal.className = "modal-overlay open";
  };
}
function initSell() {
  const form = document.getElementById("sell-form");
  if (!form) return;
  form.onsubmit = function (event) {
    event.preventDefault();
    set("sell-error", null, "none");
    set("sell-success", null, "none");
    const name = val("item-name");
    const price = parseFloat(val("item-price"));
    const image = val("item-image") || "images/default.jpg";
    if (!name || !val("item-category") || !val("item-condition") || isNaN(price) || price <= 0) {
      set("sell-error", "Please fill in all fields with a valid price.", "block");
      return;
    }
    const products = load("rewear_products", defaultProducts);
    products.unshift({ id: products.length + 1, name: name, category: val("item-category"), price: price, condition: val("item-condition"), image: image });
    localStorage.setItem("rewear_products", JSON.stringify(products));
    form.reset();
    set("sell-success", '"' + name + '" was listed! It is now on the Products page.', "block");
  };
}

window.onload = function () {
  saveCart(load("rewear_cart", []));
  renderProducts();
  renderCart();
  initCheckout();
  initSell();
  const s = document.getElementById("search-input");
  const c = document.getElementById("category-filter");
  if (s) s.oninput = renderProducts;
  if (c) c.onchange = renderProducts;
};
